memberList.jsp


회원등록 버튼 memberForm.jsp
	저장		memberInsert.jsp
	
	
회원클릭		memberList.jsp -> memberView.jsp
	수정		memberEdit.jsp
		저장	memberUpdate.jsp